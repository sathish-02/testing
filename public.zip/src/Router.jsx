import {
  createBrowserRouter,
  RouterProvider,
  // Route,
  Link,
} from "react-router-dom";
import ErrorBoundary from "./ErrorBoundary";
import Login from "./pages/login/Login";
import Home from "./pages/home/Home";

const Router = () => {
  const router = createBrowserRouter([
    {
      path: "/",
      element: (
        <div>
          <h1 className="text-3xl font-bold underline text-blue-950">
            Hello world!
          </h1>
          <Link to="about">About Us</Link>
        </div>
      ),
      errorElement: <ErrorBoundary />,
    },
    {
      path: "/login",
      element: (
        <Login/>
      ),
      errorElement: <ErrorBoundary />,
    },
    {
      path: "/new",
      element: (
       <Home from={'new'}/>
      ),
      errorElement: <ErrorBoundary />,
    },
    {
      path: "/existing",
      element: (
        <Home from={'existing'}/>
       ),
      errorElement: <ErrorBoundary />,
    },
  ]);

  return <RouterProvider router={router} />;
};

export default Router;
