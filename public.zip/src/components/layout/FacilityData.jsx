import { Steps } from "antd";
import { btnNormalClasses, btnPrimaryClasses } from "../common/DefaultClasses";
import useFacilityData from "../../hooks/facility/useFacilityData";
import FormContent from "../common/FormContent";

const FacilityData = () => {
  const { current, steps, next, prev, items } = useFacilityData();
  return (
    <div className="">
      <Steps current={current} items={items} />
      {/* className="border-2 border-dashed border-spacing-4 rounded-lg mt-6 bg-neutral-100" */}
      <div className="p-2">
        {<FormContent current={current} />}
      </div>
      <div className="flex float-end mt-4 gap-2 mb-2">
        {current > 0 && (
          <button className={`${btnNormalClasses}`} onClick={() => prev()}>
            Back
          </button>
        )}
        {current < steps.length - 1 && (
          <button className={`${btnPrimaryClasses}`} onClick={() => next()}>
            Next
          </button>
        )}
        {current === steps.length - 1 && (
          <button className={`${btnPrimaryClasses}`}>Submit</button>
        )}
      </div>
    </div>
  );
};
export default FacilityData;
