import { GiHamburgerMenu } from "react-icons/gi";
import logo from "../../assets/Img/DHL_logo_rgb_BG.png";
import useNavBar from "../../hooks/navBar/useNavBar";
import NavDrawer from "../common/NavDrawer";

const NavBar = () => {
  const { openNavBar } = useNavBar();

  return (
    <>
      <div className="flex bg-[#ffcc00] z-50 justify-between fixed left-0 right-0 top-0 items-center p-3 shadow-2xl">
        <div
          className="text-xl p-2 text-white hover:rounded-full hover:cursor-pointer hover:bg-black hover:opacity-20"
          onClick={openNavBar}
        >
          <GiHamburgerMenu />
        </div>
        <div className="w-[80px]">
          <img src={logo} alt="logo" className="w-[100%]" />
          <h1 className="text-md text-center">UMBRA UI</h1>
        </div>
      </div>
      <NavDrawer />
    </>
  );
};

export default NavBar;
