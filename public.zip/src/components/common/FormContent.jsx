import { Checkbox, Form, Input, Select } from "antd";
import PropTypes from "prop-types";
import { useMemo } from "react";
import ModuleTables from "./ModuleTables";
import TransferFile from "./TransferFile";

const FormContent = ({ current }) => {
  const steps = useMemo(() => {
    if (current === 0)
      return (
        <>
        
          <div className="m-0 p-10 flex flex-col gap-4 cstm_form">
            <div className="flex flex-row gap-4">
              <div className="border rounded-2xl w-1/2 overflow-hidden shadow-lg bg-white">
              <div className="bg-white p-2.5 border-b-[1px] border-zinc-200">
                  <h1 className="text-lg font-semibold">Client Information</h1>
                </div>
                <div className="flex flex-row gap-3 p-3.5">
                  <Form.Item
                    className="w-1/3"
                    label="Client Name"
                    name="client_name"
                    rules={[
                      {
                        required: true,
                        message: "Client Name is required.",
                      },
                    ]}
                  >
                    <Input placeholder="Client Name" />
                  </Form.Item>
                  <Form.Item
                    className="w-1/3"
                    label="Client Code"
                    name="client_code"
                    rules={[
                      {
                        required: true,
                        message: "Client Code is required.",
                      },
                    ]}
                  >
                    <Input placeholder="Client Code" />
                  </Form.Item>
                  <Form.Item
                    className="w-1/3"
                    label="MDM Client Code"
                    name="mdm_client_code"
                    rules={[
                      {
                        required: true,
                        message: "MDM Client Code is required.",
                      },
                    ]}
                  >
                    <Input placeholder="MDM Client Code" />
                  </Form.Item>
                </div>
              </div>

              <div className="border rounded-2xl w-1/2 overflow-hidden shadow-lg bg-white">
              <div className="bg-white p-2.5 border-b-[1px] border-zinc-200">
                  <h1 className="text-lg font-semibold">Target System Information</h1>
                </div>
                <div className="flex flex-row">
                  <div className="flex flex-row gap-3 p-3.5 w-full">
                    <Form.Item
                      className="w-1/3"
                      label="Target System"
                      name="target_system"
                      rules={[
                        {
                          required: true,
                          message: "Target System is required.",
                        },
                      ]}
                    >
                      <Input placeholder="Target System" />
                    </Form.Item>
                    <Form.Item
                      className="w-1/3"
                      label="Primary Customer WMS ID"
                      name="primary_customer_id"
                      rules={[
                        {
                          required: true,
                          message: "Primary Customer WMS ID is required.",
                        },
                      ]}
                    >
                      <Input placeholder="Primary Customer WMS ID" />
                    </Form.Item>
                    <Form.Item
                      className="w-1/3 cstm_label"
                      label="Secondary Customer WMS ID"
                      name="secondary_customer_id"
                    >
                      <Input placeholder="Secondary Customer WMS ID" />
                    </Form.Item>
                  </div>
                </div>
              </div>
            </div>

            <div className="flex flex-row gap-4">
              <div className="flex flex-row w-1/2">
                <div className="border rounded-2xl flex w-full flex-col overflow-hidden shadow-lg bg-white">
                <div className="bg-white p-2.5 border-b-[1px] border-zinc-200">
                    <h1 className="text-lg font-semibold">Registered Facility Information</h1>
                  </div>

                  <div className="flex flex-col p-3.5">
                    <div className="flex flex-row gap-2 mb-2">
                      <Form.Item
                        className="mb-0 w-1/2"
                        label="Choose a Facility"
                        name="register_facility"
                        rules={[
                          {
                            required: true,
                            message: "Register Facility is required.",
                          },
                        ]}
                      >
                        <Select placeholder="Choose a Facility">
                          <Select.Option value="A01">A01</Select.Option>
                          <Select.Option value="A02">A02</Select.Option>
                          <Select.Option value="A03">A03</Select.Option>
                          <Select.Option value="A04">A04</Select.Option>
                        </Select>
                      </Form.Item>
                      <Form.Item
                        className="mb-0 w-1/2"
                        label="Country"
                        name="country"
                      >
                        <Input placeholder="Country" disabled />
                      </Form.Item>
                    </div>

                    <div className="flex flex-row gap-2 mb-2">
                      <Form.Item
                        className="mb-0 w-1/2"
                        label="State"
                        name="state"
                      >
                        <Input placeholder="State" disabled />
                      </Form.Item>
                      <Form.Item
                        className="mb-0 w-1/2"
                        label="Suburb"
                        name="suburb"
                      >
                        <Input placeholder="Suburb" disabled />
                      </Form.Item>
                    </div>

                    <div className="flex flex-row gap-2 mb-2">
                      <Form.Item
                        className="mb-0 w-1/2"
                        label="Postcode"
                        name="postcode"
                      >
                        <Input placeholder="Postcode" disabled />
                      </Form.Item>
                      <Form.Item
                        className="mb-0 w-1/2"
                        label="Address Line 1"
                        name="address_1"
                      >
                        <Input placeholder="Address Line 1" disabled />
                      </Form.Item>
                    </div>

                    <div className="flex flex-row gap-2 mb-2">
                      <Form.Item
                        className="mb-0 w-1/2"
                        label="Address Line 2"
                        name="address_2"
                      >
                        <Input placeholder="Address Line 2" disabled />
                      </Form.Item>
                      <Form.Item
                        className="mb-0 w-1/2"
                        label="Address Line 3"
                        name="address_3"
                      >
                        <Input placeholder="Address Line 3" disabled />
                      </Form.Item>
                    </div>

                    <Form.Item
                      className="mb-0"
                      label="MSD_Facility ID"
                      name="msd_facility"
                    >
                      <Input placeholder="MSD_Facility ID" disabled />
                    </Form.Item>
                  </div>
                </div>
              </div>
              <div className="flex flex-row w-1/2">
                <div className="border rounded-2xl flex w-full flex-col overflow-hidden shadow-lg bg-white">
                  <div className="bg-white p-2.5 border-b-[1px] border-zinc-200">
                    <h1 className="text-lg font-semibold">Ship From Facility Information</h1>
                  </div>
                  <div className="flex flex-col p-3.5">
                    <div className="flex flex-row gap-2 mb-2">
                      <Form.Item
                        className="mb-0 w-1/2"
                        label="Choose a Facility"
                        name="register_facility"
                        rules={[
                          {
                            required: true,
                            message: "Register Facility is required.",
                          },
                        ]}
                      >
                        <Select placeholder="Choose a Facility">
                          <Select.Option value="A01">A01</Select.Option>
                          <Select.Option value="A02">A02</Select.Option>
                          <Select.Option value="A03">A03</Select.Option>
                          <Select.Option value="A04">A04</Select.Option>
                        </Select>
                      </Form.Item>
                      <Form.Item
                        className="mb-0 w-1/2"
                        label="Country"
                        name="country"
                      >
                        <Input placeholder="Country" disabled />
                      </Form.Item>
                    </div>

                    <div className="flex flex-row gap-2 mb-2">
                      <Form.Item
                        className="mb-0 w-1/2"
                        label="State"
                        name="state"
                      >
                        <Input placeholder="State" disabled />
                      </Form.Item>
                      <Form.Item
                        className="mb-0 w-1/2"
                        label="Suburb"
                        name="suburb"
                      >
                        <Input placeholder="Suburb" disabled />
                      </Form.Item>
                    </div>

                    <div className="flex flex-row gap-2 mb-2">
                      <Form.Item
                        className="mb-0 w-1/2"
                        label="Postcode"
                        name="postcode"
                      >
                        <Input placeholder="Postcode" disabled />
                      </Form.Item>
                      <Form.Item
                        className="mb-0 w-1/2"
                        label="Address Line 1"
                        name="address_1"
                      >
                        <Input placeholder="Address Line 1" disabled />
                      </Form.Item>
                    </div>

                    <div className="flex flex-row gap-2 mb-2">
                      <Form.Item
                        className="mb-0 w-1/2"
                        label="Address Line 2"
                        name="address_2"
                      >
                        <Input placeholder="Address Line 2" disabled />
                      </Form.Item>
                      <Form.Item
                        className="mb-0 w-1/2"
                        label="Address Line 3"
                        name="address_3"
                      >
                        <Input placeholder="Address Line 3" disabled />
                      </Form.Item>
                    </div>

                    <Form.Item
                      className="mb-0"
                      label="MSD_Facility ID"
                      name="msd_facility"
                    >
                      <Input placeholder="MSD_Facility ID" disabled />
                    </Form.Item>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </>
      );
    if (current === 1)
      return (
        <div className="grid grid-cols-3 gap-3">
          <div className="border border-neutral-300 px-4 rounded-lg">
            <h1 className="text-lg mb-4">Document Type</h1>

            <Form.Item
              label="Document Type"
              name="document_type"
              rules={[
                {
                  required: true,
                  message: "Document Type is required.",
                },
              ]}
            >
              <Select placeholder="Document Type">
                <Select.Option value="100">100</Select.Option>
                <Select.Option value="200">200</Select.Option>
                <Select.Option value="203">203</Select.Option>
                <Select.Option value="400">400</Select.Option>
              </Select>
            </Form.Item>
          </div>
          <div className="border border-neutral-300 px-4 rounded-lg">
            <h1 className="text-lg mb-4">Configure Module</h1>
            {/* <Form.Item name="disabled" valuePropName="checked"> */}
            <Checkbox className="mb-2">Copy from a Existing Client </Checkbox>
            {/* </Form.Item> */}
            <Form.Item
              //   label="Choose Existing Client"
              name="existing_client"
              //   rules={[
              //     {
              //       required: true,
              //       message: "Document Type is required.",
              //     },
              //   ]}
            >
              <Select placeholder="Choose Existing Client">
                <Select.Option value="SCO_3MOS_A14">SCO_3MOS_A14</Select.Option>
                <Select.Option value="SCO_3MOS_A15">SCO_3MOS_A15</Select.Option>
                <Select.Option value="SCO_3MOS_A16">SCO_3MOS_A16</Select.Option>
                <Select.Option value="SCO_3MOS_A17">SCO_3MOS_A17</Select.Option>
              </Select>
            </Form.Item>
          </div>
          <div className="border border-neutral-300 px-4 rounded-lg">
            <h1 className="text-lg mb-4">Choose Module</h1>
            <Form.Item
              //   label="Choose Module"
              name="choose_module"
              //   rules={[
              //     {
              //       required: true,
              //       message: "Document Type is required.",
              //     },
              //   ]}
            >
              <TransferFile />
            </Form.Item>
          </div>
        </div>
      );
    return (
      <div className="grid grid-cols-1 gap-3">
        <div className="border border-neutral-300 px-4 rounded-lg">
          <h1 className="text-lg mb-4">Configure Module Tables</h1>
          <ModuleTables />
        </div>
      </div>
    );
  }, [current]);
  return (
    <div>
      <Form layout="vertical">{steps}</Form>
    </div>
  );
};

FormContent.propTypes = { current: PropTypes.number };

export default FormContent;
