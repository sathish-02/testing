import { Drawer, Menu } from "antd";
import { IoIosLogOut, IoMdClose } from "react-icons/io";
import { btnNormalClasses, btnPrimaryClasses } from "./DefaultClasses";
import useNavDrawer from "../../hooks/navBar/useNavDrawer";
import { MdEditNote, MdNoteAdd } from "react-icons/md";
import { useDispatch } from "react-redux";
import { setSelectedTab } from "../../features/navDrawer/nav.slice";

const NavDrawer = () => {
  const { isOpen, selectedTab, onClose } = useNavDrawer();
  const dispatch = useDispatch();
  const items = [
    {
      key: "1",
      icon: <MdNoteAdd size={25} />,
      label: "Setup New Client",
      onClick: () => {
        dispatch(setSelectedTab(1));
      },
    },
    {
      key: "2",
      icon: <MdEditNote size={25} />,
      label: "Manage Existing Client Setup",
      onClick: () => {
        dispatch(setSelectedTab(2));
      },
    },
  ];

  return (
    <Drawer
      title="Umbra UI"
      placement={"left"}
      closable={false}
      autoFocus={false}
      onClose={onClose}
      open={isOpen}
      key={"left"}
      className="rounded-r-xl"
      footer={
        <div className="float-end flex gap-2">
          <button className={`${btnNormalClasses} flex items-center gap-2`} onClick={onClose} >
            Cancel
          </button>
          <button className={`${btnPrimaryClasses} flex items-center gap-2`}>
            <IoIosLogOut /> Logout
          </button>
        </div>
      }
      extra={
        <span
          className="text-lg opacity-70 hover:opacity-100 hover:cursor-pointer"
          onClick={onClose}
        >
          <IoMdClose />
        </span>
      }
    >
      <Menu
        defaultSelectedKeys={selectedTab === 1 ? ["1"] : ["2"]}
        defaultOpenKeys={["sub1"]}
        mode={"inline"}
        theme={"light"}
        items={items}
        style={{border:'none'}}
      />
    </Drawer>
  );
};

export default NavDrawer;
