import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  isOpen: false,
  selectedTab: 1
};

export const navDrawerSlice = createSlice({
  name: "navbar",
  initialState,
  reducers: {
    openDrawer: (state, {payload}) => {
      state.isOpen = payload;
    },
    setSelectedTab: (state,{payload})=> {
        state.selectedTab = payload
    }
  },
});

// Action creators are generated for each case reducer function
export const { openDrawer,setSelectedTab } = navDrawerSlice.actions;
const navDrawerReducer = navDrawerSlice.reducer;
const isOpenNavDrawer = (state) => state.navbar;

export { navDrawerReducer, isOpenNavDrawer };
