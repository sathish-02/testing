import FacilityData from "../../components/layout/FacilityData"
import NavBar from "../../components/layout/NavBar"


const Home = () => {


  return (
    <div className="bg-homePage w-screen h-screen p-4">
        <NavBar/>
        <FacilityData/>
    </div>
  )
}

export default Home