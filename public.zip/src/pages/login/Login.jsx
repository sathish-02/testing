import logo from "../../assets/Img/DHL_logo_rgb_BG.png";

const Login = () => {
  return (
    <div className="bg-custom-gradient grid place-items-center h-screen w-screen">
      <div className="w-[450px] h-[320px] flex justify-center items-center p-6 shadow-xl rounded-2xl border border-yellow-300 bg-white bg-opacity-80">
        <div className="flex flex-col gap-2 w-[80%] items-center">
          <img src={logo} alt="logo" className="w-[230px]" />
          <h1 className="text-xl text-center font-medium opacity-70 w-full">
            DSC BPMS
          </h1>
          <button className="mt-8 bg-[#CC0001] text-white text-base rounded-full px-5 py-2.5 font-semibold transform transition-transform outline-none border-none hover:shadow-2xl focus:outline-none flex flex-row items-center justify-between gap-2 relative">
            <span className='pe-6'>Sign in with SSO</span>
            <span className="bg-[#910c0c] flex items-center rounded-full h-[32px] w-[32px] justify-center gap-2 absolute right-1.5">
              <svg
                stroke="currentColor"
                fill="currentColor"
                stroke-width="0"
                viewBox="0 0 24 24"
                height="1em"
                width="1em"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  fill="none"
                  stroke-width="2"
                  d="M6,12.4 L18,12.4 M12.6,7 L18,12.4 L12.6,17.8"
                ></path>
              </svg>
            </span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default Login;
