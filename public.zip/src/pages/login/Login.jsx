import logo from "../../assets/Img/DHL_logo_rgb_BG.png";

const Login = () => {
  return (
    <div className="bg-custom-gradient grid place-items-center h-screen w-screen">
      <div className="w-[500px] h-[300px] flex justify-center items-center p-6 shadow-xl rounded-2xl border border-yellow-300 bg-white bg-opacity-50">
        <div className="flex flex-col gap-2 w-[80%]">
          <img src={logo} alt="logo" className="w-[100%]"/>
          <h1 className="text-2xl text-center font-medium opacity-70 w-full">
            DSC BPMS
          </h1>
          <button className="mt-8 bg-[#CC0001] text-white text-xl rounded-full px-8 py-4 font-semibold transform transition-transform outline-none border-none hover:shadow-2xl focus:outline-none">
            {" "}
            Sign in with SSO
          </button>
        </div>
      </div>
    </div>
  );
};

export default Login;
