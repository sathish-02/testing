import { configureStore } from '@reduxjs/toolkit'
import { navDrawerReducer } from '../features/navDrawer/nav.slice'

export const store = configureStore({
  reducer: {
    navbar: navDrawerReducer,
  },
})