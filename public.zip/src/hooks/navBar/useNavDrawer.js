import { useCallback } from "react";
import {
  isOpenNavDrawer,
  openDrawer,
} from "../../features/navDrawer/nav.slice";
import { useDispatch, useSelector } from "react-redux";

const useNavDrawer = () => {
  const { isOpen,selectedTab } = useSelector(isOpenNavDrawer);
  
  const dispatch = useDispatch();
  const onClose = useCallback(() => {
    dispatch(openDrawer(false));
  }, [dispatch]);

  return {
    isOpen,
    selectedTab,
    onClose,
  };
};

export default useNavDrawer;
