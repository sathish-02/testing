import { useCallback } from "react"
import { useDispatch } from "react-redux"
import { openDrawer } from "../../features/navDrawer/nav.slice"


const useNavBar = () => {
    const dispatch = useDispatch()
    const openNavBar = useCallback(()=>{
        dispatch(openDrawer(true))
    },[dispatch])

  return {openNavBar}
}

export default useNavBar