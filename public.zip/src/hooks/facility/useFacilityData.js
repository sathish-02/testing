import { theme } from "antd";
import { useCallback, useMemo, useState } from "react";
import { goToTop } from "../../utils/util";

const useFacilityData = () => {
  const { token } = theme.useToken();
  const [current, setCurrent] = useState(0);

  const steps = useMemo(
    () => [
      {
        title: "Add Client & Facility",
        description: "View Details",
      },
      {
        title: "Add Modules",
        content: "Second-content",
        description: "View Details",
      },
      {
        title: "Configure Each Module",
        description: "View Details",
      },
    ],
    []
  );

  const next = useCallback(() => {
    setCurrent(current + 1);
    goToTop()
  }, [current]);

  const prev = useCallback(() => {
    setCurrent(current - 1);
    goToTop()
  }, [current]);

  const items = useMemo(
    () =>
      steps.map((item) => ({
        key: item.title,
        title: item.title,
        description: item.description,
      })),
    [steps]
  );

  return {
    token,
    current,
    steps,
    items,
    next,
    prev,
  };
};

export default useFacilityData;
