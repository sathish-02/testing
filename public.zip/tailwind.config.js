/** @type {import('tailwindcss').Config} */
import react from '@vitejs/plugin-react'
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,jsx}",
  ],
  theme: {
    extend: {
      
      backgroundImage: {
        'custom-gradient': 'linear-gradient(to right, #F7E3A8, #F1C40F)',
        'dashboardColor': '#d62626d9',
      },
      colors: {
        'homePage': '#FFFFFF  ',
      },
     
    },
  },
  plugins: [react()],
}

